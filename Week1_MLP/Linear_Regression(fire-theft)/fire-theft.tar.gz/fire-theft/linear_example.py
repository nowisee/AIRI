"""
    simple linear regression

"""


import tensorflow as tf
from fire_theft import *

#
# Create model 
#

# placeholder

# Variable

# Linear function

# loss function

# Optimizer

#
#  Session run
#
with tf.Session() as sess:

    # tensorflow variable init
    
    for i in range(100):

        # 
        
        for x, y in fire_theft_data:
            print('training..')
            #  sess.run(...) for training


    # print out trained variables
    print('trained value: w=?, b=?')

